import os, httpx

OPENAI_API_KEY=os.getenv("OPENAI_API_KEY")
OPENAI_MODEL=os.getenv("OPENAI_MODEL","gpt-4o-mini")
URL="https://api.openai.com/v1/chat/completions"

async def call_llm_openai(prompt,system=None,temperature=0.2,max_tokens=800):
    if not OPENAI_API_KEY:
        raise RuntimeError("Missing OPENAI_API_KEY")
    headers={"Authorization":f"Bearer {OPENAI_API_KEY}","Content-Type":"application/json"}
    msgs=[]
    if system: msgs.append({"role":"system","content":system})
    msgs.append({"role":"user","content":prompt})
    payload={"model":OPENAI_MODEL,"messages":msgs,"temperature":temperature,"max_tokens":max_tokens}
    async with httpx.AsyncClient(timeout=30) as c:
        r=await c.post(URL,headers=headers,json=payload)
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"]
