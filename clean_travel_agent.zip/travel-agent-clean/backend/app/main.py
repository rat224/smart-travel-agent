from fastapi import FastAPI
from pydantic import BaseModel
from app.agent import TravelAgent

app=FastAPI()
agent=TravelAgent()

@app.get("/")
def home():
    return {"message":"Smart Travel Agent API is running 🚀"}

class TravelRequest(BaseModel):
    user_id:str
    destination:str
    start_date:str
    end_date:str
    budget:str|None=None
    preferences:dict|None=None

@app.post("/plan")
async def plan_trip(req:TravelRequest):
    return await agent.plan_trip(req.dict())
