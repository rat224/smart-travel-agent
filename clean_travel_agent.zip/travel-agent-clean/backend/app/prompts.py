def itinerary_prompt(req,coords,flights,hotels,weather):
    return f"USER:{req}\nCOORDS:{coords}\nFLIGHTS:{flights}\nHOTELS:{hotels}\nWEATHER:{weather}"
