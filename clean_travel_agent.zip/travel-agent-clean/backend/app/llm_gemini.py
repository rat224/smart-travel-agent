import os, httpx

GEMINI_API_KEY=os.getenv("GEMINI_API_KEY")
MODEL="gemini-1.5-flash"
URL=f"https://generativelanguage.googleapis.com/v1beta/models/{MODEL}:generateContent"

async def call_llm_gemini(prompt,system=None):
    if not GEMINI_API_KEY:
        raise RuntimeError("Missing GEMINI_API_KEY")
    body={"contents":[{"parts":[{"text": (system+"\n"+prompt) if system else prompt}]}]}
    async with httpx.AsyncClient(timeout=30) as c:
        r=await c.post(URL+f"?key={GEMINI_API_KEY}",json=body)
        r.raise_for_status()
        data=r.json()
        return data["candidates"][0]["content"]["parts"][0]["text"]
