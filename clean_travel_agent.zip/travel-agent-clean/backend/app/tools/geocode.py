import httpx
async def geocode_place(place):
    url=f"https://geocoding-api.open-meteo.com/v1/search?name={place}"
    async with httpx.AsyncClient() as c:
        j=(await c.get(url)).json()
        if j.get('results'):
            f=j['results'][0]
            return {'name':f['name'],'lat':f['latitude'],'lon':f['longitude']}
        return {'name':place,'lat':None,'lon':None}
