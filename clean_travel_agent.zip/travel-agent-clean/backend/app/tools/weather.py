import httpx
async def get_weather_forecast(lat,lon,start,end):
    if lat is None: return {}
    url=f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&hourly=temperature_2m&start_date={start}&end_date={end}"
    async with httpx.AsyncClient() as c:
        return (await c.get(url)).json()
