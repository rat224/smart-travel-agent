async def search_flights_mock(dest,start,end):
    return [{"airline":"MockAir","price":"25000","link":"#"}]

async def search_hotels_mock(dest,start,end):
    return [{"name":"Hotel A","price":"3000/night","rating":4.2,"link":"#"}]
