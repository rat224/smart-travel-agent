from .tools.geocode import geocode_place
from .tools.weather import get_weather_forecast
from .tools.flights import search_flights_mock, search_hotels_mock
from .prompts import itinerary_prompt
from .llm_openai import call_llm_openai
from .llm_gemini import call_llm_gemini
import json

class TravelAgent:
    async def plan_trip(self, req):
        dest=req['destination']
        start=req['start_date']
        end=req['end_date']

        coords=await geocode_place(dest)
        weather=await get_weather_forecast(coords.get('lat'),coords.get('lon'),start,end)
        flights=await search_flights_mock(dest,start,end)
        hotels=await search_hotels_mock(dest,start,end)

        prompt=itinerary_prompt(req,coords,flights,hotels,weather)
        system="You are a travel planner. Output valid JSON."

        try:
            out=await call_llm_openai(prompt,system=system)
        except:
            out=await call_llm_gemini(prompt,system)

        parsed=None
        try:
            s=out.find('{'); e=out.rfind('}')
            if s!=-1 and e!=-1:
                parsed=json.loads(out[s:e+1])
        except: pass

        return {"destination":dest,"coords":coords,"flights":flights,
                "hotels":hotels,"weather":weather,
                "itinerary_text":out,"itinerary_json":parsed}
